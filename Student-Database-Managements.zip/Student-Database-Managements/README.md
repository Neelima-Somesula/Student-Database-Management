# Student Database Management Project

## Overview
Centralized student record management system using:
- Canvas Apps (Power Apps)
- Power Automate flows
- Power BI dashboards

## Features
- Canvas App to manage student records
- Automated approval workflows
- Power BI dashboard for performance insights

## Folder Structure
- CanvasApp/: Canvas App file and instructions
- PowerAutomateFlows/: Flow JSON and instructions
- PowerBI/: Power BI dashboard file and instructions
- Data/: Sample CSV files

## Instructions to Run
1. Import the Canvas App in Power Apps Studio.
2. Import the Power Automate flow in Power Automate.
3. Open the Power BI dashboard in Power BI Desktop and connect to CSV data.

# Power Automate Flow - ApprovalFlow.json

## Instructions
1. Go to Power Automate.
2. Click 'Import' and select this JSON file.
3. Update connections to match your data sources.

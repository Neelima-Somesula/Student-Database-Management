# Power BI Dashboard - StudentDashboard.pbix

## Instructions
1. Open Power BI Desktop.
2. Load the Students.csv and Courses.csv files from the Data/ folder.
3. Use provided visualizations to explore student performance insights.

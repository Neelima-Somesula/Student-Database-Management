# Canvas App - StudentApp.msapp

## Instructions
1. Open Power Apps Studio.
2. Click 'Import canvas app' and select this file.
3. Connect to the CSV files in Data/ folder or your Dataverse environment.
